import base64
import cv2
import json
import numpy as  np


def getImg(img64):
    img_data=base64.b64decode(img64) 
    nparr = np.fromstring(img_data,np.uint8)  
    img=cv2.imdecode(nparr,cv2.COLOR_BGR2RGB)
    img = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
    img=cv2.resize(img,(224,224))
    img=np.swapaxes(img,0,2)
    img=np.swapaxes(img,1,2)
    img = img[np.newaxis,:]
    return img

def response(body):
    responseHeaderLines = "HTTP/1.1 200 OK\r\n"
    responseHeaderLines += 'application/json\r\n'
    responseHeaderLines += "\r\n"
    responseBody = body
    response = responseHeaderLines + responseBody
    return response

def parse(recvData):
    #print  recvData
    request_line, body = recvData.split('\r\n', 1)  
    header_list = request_line.split(' ')
    method = header_list[0].upper()
    protel,data = body.split('\r\n\r\n', 1)
    content = {}
    for i in protel.split('\r\n'):
       key,val = i.split(':',1)
       content[key.strip()] = val.strip()
    return method,content,data

def getPost(data,type):
  if type == 'application/x-www-form-urlencoded':
      request_data = {}
      for i in data.split('&'):
          key,val = i.split('=')
          request_data[key] = val
      return request_data
  elif type == 'application/json' :
       return json.loads(data)
  else:
     return {}
      


