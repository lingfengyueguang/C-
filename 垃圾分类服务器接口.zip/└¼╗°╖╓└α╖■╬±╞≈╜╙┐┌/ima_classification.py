import mxnet as mx
import matplotlib.pyplot as plt
import cv2
import numpy as np
from collections import namedtuple
import time

def Init():
    sym, arg_params, aux_params = mx.model.load_checkpoint('../model/resnet50_', 298)
    mod = mx.mod.Module(symbol=sym, context=mx.cpu(), data_names=['data'], label_names=None)
    mod.bind(for_training=False, data_shapes=[('data', (1, 3, 224, 224))])
    mod.set_params(arg_params, aux_params,allow_missing=True)
    Batch = namedtuple('Batch', ['data'])
    print('Init Finish' )
    return mod,Batch

def predict(mod,Batch,img,id):
    mod.forward(Batch([mx.nd.array(img)]))
    prob = mod.get_outputs()[0].asnumpy()
    prob = np.squeeze(prob)
    prob = np.argsort(prob)[::-1]
    usable = prob[0]
    if usable == 0:
        grade = 1
    else:
        grade = 4
    return id,usable,grade
