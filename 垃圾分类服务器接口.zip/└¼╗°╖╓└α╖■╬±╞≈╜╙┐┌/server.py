#coding=utf-8
import socket
from tool import *
from ima_classification import Init,predict
import json
def handleClient(clientSocket,mod,Batch):
    recvData = []
    while True:
         buf = clientSocket.recv(1024).decode()
         #recvData += str(buf)
         recvData += buf
         #print (recvData.shape)
         _,content,_ = parse(''.join(recvData))
         #print (int(content['Content-Length']),len(recvData))
         if len(recvData) >= int(content['Content-Length']):
             break
    method,content,data = parse(''.join(recvData))

    if method == 'POST':
        request_data = getPost(data,content['Content-Type'])
    else:
       clientSocket.close() 

    #if request_data.has_key('id') and request_data.has_key('img'):
    if 'id' in request_data.keys() and 'img' in request_data.keys():
        recid = request_data['id']
        img = getImg(request_data['img'])
    #print img.shape
    #cv2.imshow('rec',img)
    #cv2.waitKey(1000)
        id,usable,grade =  predict(mod,Batch,img,recid)
        result = json.dumps({"id":int(id),"usable":int(usable),"grade":int(grade)})
        clientSocket.send(response(result).encode(encoding = 'utf-8'))
    else:
        pass
    clientSocket.close()


