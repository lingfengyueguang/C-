#coding=utf-8
import socket
from multiprocessing import Process
import threading
from tool import *
from ima_classification import Init,predict
from server import handleClient

def main():
    mod,Batch = Init()
    serverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    serverSocket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    serverSocket.bind(('127.0.0.1',7766))
    serverSocket.listen(10)
    threads = []
    while True:
        clientSocket,clientAddr = serverSocket.accept()
        clientP = threading.Thread(target = handleClient, args = (clientSocket,mod,Batch))
        #clientP =  Process(target = handleClient, args = (clientSocket,mod,Batch))
        #clientP.daemon = True
        clientP.start()
        #clientSocket.close()

if __name__ == '__main__':
    main()