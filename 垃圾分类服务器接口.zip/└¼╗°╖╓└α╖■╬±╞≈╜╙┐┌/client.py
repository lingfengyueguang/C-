import urllib
import urllib2
import json
import base64
with open("04.JPG", "rb") as imageFile:
    img = base64.b64encode(imageFile.read())
test_data = {'id': '2', 'img': img}
headers = {'Content-Type': 'application/json'}
requrl = "http://127.0.0.1:7766"
#req = urllib2.Request(url=requrl, data=test_data_urlencode)

req = urllib2.Request(url=requrl,headers=headers, data=json.dumps(test_data))

res_data = urllib2.urlopen(req)
res = res_data.read()
print (res)


