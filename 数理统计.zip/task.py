#coding=utf-8
# Load libraries
import pandas
import numpy as np
import scipy.stats as stats
import matplotlib.pyplot as plt


def getVar(x):
    u= x.mean(axis=0)
    xt =  x-u
    n,h = x.shape
    sum = np.zeros((h,h))
    
    
    for i in range(len(xt)):
        a=xt[i].reshape(-1,1)
        b=xt[i].reshape(1,-1)
        sum+=np.dot(a,b)

    return sum/n
 
def Gass(x,u,var):
    t1 = (x - u).reshape(1,-1)
    t2 = (x - u).reshape(-1,1)
    temp = np.dot(t1,var)
    temp = np.dot(temp,t2)
    return (np.exp(-0.5*temp)).squeeze()
from sklearn.datasets import load_iris   #导入数据集iris
iris = load_iris() 

data = iris.data  
y = iris.target
index1 = np.array(np.where(y==0)).squeeze()
index2 = np.array(np.where(y==1)).squeeze()
index3 = np.array(np.where(y==2)).squeeze()
x1 = data[index1[:25]]
x2 = data[index2[:25]]
x3 = data[index3[:25]]
y1 = y[index1[:25]]
y2 = y[index2[:25]]
y3 = y[index3[:25]]

u1= x1.mean(axis=0)
u2=x2.mean(axis=0)
u3=x3.mean(axis=0)
u1= x1.mean(axis=0)
u2=x2.mean(axis=0)
u3=x3.mean(axis=0)

x1t =  x1-u1
sum = np.zeros((4,4))
for i in range(len(x1t)):
    a=x1t[i].reshape(-1,1)
    b=x1t[i].reshape(1,-1)
    sum+=np.dot(a,b)

var1 = getVar(x1)
var2 = getVar(x2)
var3 =  getVar(x3)

x1 = data[index1[25:]]
x2 = data[index2[25:]]
x3 = data[index3[25:]]
y1 = y[index1[25:]]
y2 = y[index2[25:]]
y3 = y[index3[25:]]
cout1 = 0
cout3 = 0
cout2 = 0
f=open('result.txt','w')
for x in x1:
  p1 = Gass(x,u1,var1)
  p2 = Gass(x,u2,var2)
  p3 = Gass(x,u3,var3)
  #print p1,p2,p3
  f.write(str(p1)+','+str(p2)+','+str(p3)+',')
  s = np.array([p1,p2,p3])
  index = np.where(s==s.max())[0][0]+1
  if(index==1):
      cout1+=1
  f.write(str(index)+','+str(1)+'\n')


for x in x2:
  p1 = Gass(x,u1,var1)
  p2 = Gass(x,u2,var2)
  p3 = Gass(x,u3,var3)
  #print p1,p2,p3
  f.write(str(p1)+','+str(p2)+','+str(p3)+',')
  s = np.array([p1,p2,p3])
  index = np.where(s==s.max())[0][0]+1
  f.write(str(index)+','+str(2)+'\n')
  if(index==2):
      cout2+=1
for x in x3:
  p1 = Gass(x,u1,var1)
  p2 = Gass(x,u2,var2)
  p3 = Gass(x,u3,var3)
  #print p1,p2,p3
  f.write(str(p1)+','+str(p2)+','+str(p3)+',')
  s = np.array([p1,p2,p3])
  index = np.where(s==s.max())[0][0]+1
  f.write(str(index)+','+str(3)+'\n')
  if(index==3):
      cout3+=1
f.close()
print (cout1+cout2+cout3)/75.0