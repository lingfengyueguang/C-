#coding=utf-8
import scipy.io as scio
import numpy  as  np  
import numpy
import sklearn
from sklearn.linear_model import  LinearRegression
from sklearn.datasets import load_boston
import matplotlib.pyplot as plt


def get(x,c,qe):
    sum = 0
    w,l = x.shape
    y = np.zeros(w)
    for n in range(w):
        for i in range(l):
            for j in range(l):
                sum = sum + c[i,j]*x[n,i]*x[n,j]
        s = np.sqrt(1+sum)
        y[n] = 1.64*s*np.sqrt(qe/389)
    return y

boston = load_boston()
sampleRatio = 0.8
n_samples = len(boston.target)
sampleBoundary = int(n_samples * sampleRatio)

shuffleIdx = range(n_samples)
np.random.shuffle(shuffleIdx) # 需要导入numpy


train_features = boston.data[shuffleIdx[:sampleBoundary]]
train_targets = boston.target[shuffleIdx[:sampleBoundary]]


test_features = boston.data[shuffleIdx[sampleBoundary:]]
test_targets = boston.target[shuffleIdx[sampleBoundary:]]


lr = LinearRegression(fit_intercept=True)
index = [0,1,3,4,5,7,8,9,10,12] 
train_features = train_features[:,index]
lr.fit(train_features, train_targets) # 拟合

t = test_features[:,index]
y_p1 = lr.predict(t) # 预测

t2 = train_features
y_p = lr.predict(t2)
y = train_targets
y_var = train_targets.mean()
c_ = np.dot(train_features.T,train_features)
c = np.linalg.inv(c_)


qt = np.square(y - y_var).sum()
qe = np.square(y-y_p).sum()
qr = np.square(y_p-y_var).sum()

s = get(t,c,qe)
y1 = test_targets - s
y2 = test_targets + s
acc =0 
for i in range(len(y_p1)):
    if y_p1[i]< y2[i] and y_p1[i]>y1[i] :
        acc +=1
print acc
plt.plot(test_targets, y1, 'gd') # y = ωX
plt.plot(test_targets, y2, 'gd')
plt.plot(test_targets, y_p1, 'rx')
plt.plot([test_targets.min(), test_targets.max()], [test_targets.min(), test_targets.max()], 'b-.', lw=4) # f(x)=x
plt.ylabel("Predieted Price")
plt.xlabel("Real Price")


plt.xlim((1, 35))
plt.ylim((1, 35))

my_x_ticks = np.arange(0, 35, 5)
my_y_ticks = np.arange(0, 35, 5)
plt.xticks(my_x_ticks)
plt.yticks(my_y_ticks)

plt.show()
'''
y = train_targets
y_var = train_targets.mean()
c_ = np.dot(train_features.T,train_features)
c = np.linalg.inv(c_)
b = lr.coef_
print b
print lr.intercept_
bb = b[:,np.newaxis]
qe = np.square(y-y_p).sum()

for j in range(13):

   t = b[j]/np.sqrt(c[j][j])/np.sqrt(qe/389)
   print t

print c[0][0]
qt = np.square(y - y_var).sum()
qe = np.square(y-y_p).sum()
qr = np.square(y_p-y_var).sum()
#print y.shape
#print lr.coef_
#print lr.intercept_
print qr,qe,qt,qr/13,qe/390,  qr*390/(qe*13)
'''
'''
import matplotlib.pyplot as plt
plt.plot(y, test_targets, 'rx') # y = ωX
plt.plot([y.min(), y.max()], [y.min(), y.max()], 'b-.', lw=4) # f(x)=x
plt.ylabel("Predieted Price")
plt.xlabel("Real Price")
plt.show()

x = boston.data
y = boston.target

print x.shape
'''