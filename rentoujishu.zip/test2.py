#coding=utf-8
import cv2
import numpy as np
import os
f = os.listdir("danren44")
for item in f:

    img = os.path.join("danren44",item)
    img = cv2.imread(img)
    cv2.imshow("img",img)
    cv2.waitKey(0)
   