#coding=utf-8
import cv2
import numpy as np
import os
kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(20,20))

bs = cv2.createBackgroundSubtractorKNN(detectShadows = True)

'''


back = cv2.imread(os.path.join("danren44",'1.jpg'))
img1 = cv2.imread(os.path.join("danren44",'16.jpg'))
img1[img1>127] = 255
back[back>127] = 255
back = 255 - back
img =   back + img1
img[img>127] = 255
closed = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel)
cv2.imshow('img',img)
cv2.imshow('closed',closed)
cv2.imshow('back',back)
cv2.imshow('img1',img1)
cv2.waitKey(0)


video = cv2.VideoCapture('test.avi')

success, frame = video.read()
 
while success :
    cv2.imshow("Oto Video", frame) 
    cv2.waitKey(1000) 
    videoWriter.write(frame) 
    success, frame = video.read() 



import cv2
import numpy as np
 
'''
camera = cv2.VideoCapture('test.avi')
 
es = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (10,10))
kernel = np.ones((5,5),np.uint8)
background = None
 
while (True):
    
    ret, frame = camera.read()
    fgmask = bs.apply(frame)
    th = cv2.threshold(fgmask.copy(), 244, 255, cv2.THRESH_BINARY)[1]
    th = cv2.erode(th, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3,3)), iterations = 2)
    dilated = cv2.dilate(th, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (8,3)), iterations = 2)
    
    image, contours, hier = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    for c in contours:
        if cv2.contourArea(c) > 1000:
            (x,y,w,h) = cv2.boundingRect(c)
            cv2.rectangle(frame, (x,y), (x+w, y+h), (255, 255, 0), 2)
    
    cv2.imshow("mog", fgmask)
    cv2.imshow("thresh", th)
    cv2.imshow("diff", frame & cv2.cvtColor(fgmask, cv2.COLOR_GRAY2BGR))
    cv2.imshow("detection", frame)

    key=cv2.waitKey(0)
    if(key==0x1B):
        break
    else:
        continue
'''
    k = cv2.waitKey(30) & 0xff
    if k == 27:
        break
'''

    
cv2.waitKey(0)
cv2.destroyAllWindows()

