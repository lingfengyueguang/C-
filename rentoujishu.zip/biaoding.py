#coding=utf-8
import cv2
import numpy as np
import os
f=open("test.dat","rb")
index1=0
index2=0



while(True):
    data = f.read(76800*4)
    if not data:
        break
    nparr = np.fromstring(data,np.float32) 
    
    img = nparr.reshape((240,320))
    img[img>1.1] = 2
    
    img = img/2*255
    img = img.astype(np.uint8)

    cv2.imshow('img',img)
  
  

  



    key=cv2.waitKey(0)
    if(key==0x1B):
        break
    elif(key==65):
        cv2.imwrite(os.path.join("back",str(index1)+'.jpg'),img)
        index1=index1+1
    elif(key==83):
        cv2.imwrite(os.path.join("front",str(index2)+'.jpg'),img)
        index2=index2+1
    else:
        continue



