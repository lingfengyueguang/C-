#coding=utf-8
import cv2
import numpy as np
import os
f=open("test.dat","rb")
index=0


#videoWriter = cv2.VideoWriter('test.avi',cv2.VideoWriter_fourcc('X', 'V', 'I', 'D'), 30, (320,240),0)
while(True):
    data = f.read(76800*4)
    if not data:
        break
    nparr = np.fromstring(data,np.float32) 
    
    img = nparr.reshape((240,320))
    cv2.imshow('orign',img.copy())
    img[img>2] = 2
    img = img/2*255
    img = img.astype(np.uint8)
    #print img
    cv2.imshow('img',img)
    #videoWriter.write(img)
    index = index+1

    #cv2.imshow('img',img)
    cv2.waitKey(10)
    #cv2.imwrite(os.path.join("danren44",str(index)+'.jpg'),img)
    #cv2.waitKey(0)

    key=cv2.waitKey(0)
    if(key==0x1B):
        break
    elif(key==65):
        cv2.imwrite(os.path.join("danren44",str(index)+'.jpg'),img)
    else:
        continue

    index = index+1

'''
#videoWriter.release()
'''