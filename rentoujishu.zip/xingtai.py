#coding=utf-8
import cv2
import numpy as np
import os
kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(20,20))


'''

back = cv2.imread(os.path.join("danren44",'1.jpg'))
img1 = cv2.imread(os.path.join("danren44",'16.jpg'))
img1[img1>127] = 255
back[back>127] = 255
back = 255 - back
img =   back + img1
img[img>127] = 255
closed = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel)
cv2.imshow('img',img)
cv2.imshow('closed',closed)
cv2.imshow('back',back)
cv2.imshow('img1',img1)
cv2.waitKey(0)


video = cv2.VideoCapture('test.avi')

success, frame = video.read()
 
while success :
    cv2.imshow("Oto Video", frame) 
    cv2.waitKey(1000) 
    videoWriter.write(frame) 
    success, frame = video.read() 



import cv2
import numpy as np
 
'''
camera = cv2.VideoCapture('test.avi')
 
es = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (10,10))
kernel = np.ones((5,5),np.uint8)
background = None
 
while (True):
    ret, frame = camera.read()
    if background is None:
        background = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        background = cv2.GaussianBlur(background, (21, 21), 0)
        continue
    
    gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    gray_frame = cv2.GaussianBlur(gray_frame, (21, 21), 0)
    
    diff = cv2.absdiff(background, gray_frame)#得到一个差分图
    diff = cv2.threshold(diff,100, 255, cv2.THRESH_BINARY)[1]#固定阈值处理黑白图
    diff = cv2.dilate(diff, es, iterations = 2)#膨胀处理图像
    
    image, cnts, hierarchy = cv2.findContours(diff.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    for c in cnts:
        if cv2.contourArea(c) < 1500:
            continue
        (x, y, w, h) = cv2.boundingRect(c)
        cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 255, 0), 2)
    
    cv2.imshow("contours", frame)
    cv2.imshow("dif", diff)
    if cv2.waitKey(int(10)) & 0xff == ord("q"):
        break
    
cv2.waitKey(0)
cv2.destroyAllWindows()

